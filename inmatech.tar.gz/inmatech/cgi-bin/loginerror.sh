#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config

if [ -n "$QUERY_STRING" ];then
	USERNAME_LOGIN=$(echo "$QUERY_STRING" | cut -d":" -f1 | sed 's/data=//g' | $C_ZT_BIN_DIR/base64 --decode)
	PASSWORD_LOGIN=$(echo "$QUERY_STRING" | cut -d":" -f4 | $C_ZT_BIN_DIR/base64 --decode)
fi

POST=$(</dev/stdin)
if [ -n "$POST" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR")\"
	done
fi

if [ -n "$CLOSE" ];then
	echo "<script>setTimeout('window.close()', 500);</script>"
	exit
fi

if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
source /DB/apache2/cgi-bin/zerotruth/functions.sh

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>

EOF

echo "</head><body><p>"
echo "<div id=\"scheda\"></div>
<div id=\"logouser\"></div>"
$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME_LOGIN" "UPDATE"
ldap_search_people "uid=$USERNAME_LOGIN"
ldap_search_radius "$USERNAME_LOGIN"
PASS_BLOCKED=$(echo "$PASSWORD" | cut -sd'-' -f1)
CLASS_BLOCKED="$(cat $C_CLASSES_DIR/$CLASS/Blocked 2>/dev/null)"
if [ "$CLASS_BLOCKED" == "yes" ];then
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<font color=\"red\">$L_WRONG_LOGIN</font><p>$L_ACCOUNT_BLOCKED
	<form action=\"loginerror.sh\" method=\"post\">
	<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
	</td></tr></table></div>
	<div id=\"scritta\">$C_HOTSPOT_NAME</div>
	/body></html>"
	exit
fi
[ -n "$PASS_BLOCKED" ] && PASSWORD="$PASS_BLOCKED"

if [[ "$USERNAME_LOGIN" != "$USERNAME" || "$PASSWORD_LOGIN" != "$PASSWORD" ]];then
	MISSING_USER="yes"
	CONNECTED=$(ls $C_CP_DIR/Connected)
	SIMULTANEOUS=$(cat  $C_CP_DIR/Simultaneous)
	for IP in "$CONNECTED";do
		if [ $( cat $C_CP_DIR/Connected/$IP/User | cut -d'@' -f1) == "$USERNAME" ];then
			USERCONNECT="yes"
		fi
	done
	if [[ -n "$USERCONNECT" && "$SIMULTANEOUS" == "no" ]];then
		NOTICE="$L_SIM_CONNECTION_NOT"
		CONSIM="yes"
	else
		NOTICE="$L_MISSING_USER"
	fi
else
	if [ "$VALIDITY" == "C" ];then
			NOTICE="$L_CREDIT_NOT_AVAILABLE<br>"
			NOCREDIT="yes"
	fi
	if [ "$VALIDITY" == "M" ];then
		NOTICE="$NOTICE $L_MB_LIMIT_REACHED<br>"
	fi
	if [ "$VALIDITY" == "T" ];then
		NOTICE="$NOTICE $L_HOUR_LIMIT_REACHED<br>"
	fi
	if [ "$VALIDITY" == "E" ];then
		NOTICE="$NOTICE $L_EXCEEDED_EXPIRY_DATE"
	fi
	if [[ -n "$C_NEW_REGISTER" && -z "$NOCREDIT" ]];then
		NOTICE="$NOTICE<br>$L_ACCOUNT_EXPIRED_NEW"
	else
		if [[ -n "$NOCREDIT" && -n "$C_ACTIVE_PP" ]];then
			NOTICE="$NOTICE"
		else
			HT="$(echo "$HOSTNAME" | cut -d'.' -f1)"
			YEAR="$(date +%Y)"
			MONTH="$(date +%b)"
			DAY="$(date +%d)"
			CCPL="$(cat /Database/LOG/$YEAR/$MONTH/$DAY/$HT/CaptivePortal | tail -2 | head -1)"
			if [ -n "$(echo "$CCPL" | grep "not authorized for the user $USERNAME_LOGIN")" ];then
					CDOMAIN="$(echo "$CCPL" |  awk '{print $8}')"
					NOTICE="$NOTICE<br>Domain $CDOMAIN $L_NOT_ALLOWED"
			else
				NOTICE="$NOTICE<br>$L_ACCOUNT_PROBLEM"
			fi
		fi
	fi
	if [[ "$VALIDITY" == "yes" && -n "$PASS_BLOCKED" ]];then
		NOTICE="$L_ACCOUNT_BLOCKED"
		BLOCKED="yes"
	fi
fi
echo "<div id=\"paginaprivacy\">
<table class=\"tabella\" align=\"center\">
<tr><td align=\"center\">"
echo "<p><font color=\"red\">$L_WRONG_LOGIN</font><p>$NOTICE"
if [[ -n "$C_NEW_REGISTER" && -z "$BLOCKED" && -z "$NOCREDIT" && -z "$CONSIM" && -z "$MISSING_USER" ]];then
	echo "<form action=\"register.sh\" method=\"post\">
	<input type=\"hidden\" name=\"USERNAME_LOGIN\"  value=\"$USERNAME_LOGIN\">
	<input type=\"submit\" name=\"CONTROL_NEW_REGISTER\" class=\"bottone\" value=\"$L_REGISTER\"></form>"
else
	MAC=$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)
	MAC=$(echo "$MAC" | tr '[:lower:]' '[:upper:]')
	MACS="$(echo $MAC | sed 's/\://g')"
	if [[ -n "$C_WAIT_LOGIN" && -n "$MISSING_USER" && -z "$CONSIM" ]];then
		if ! [ -d $C_ZT_LOG_DIR/controllogin ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_LOG_DIR/controllogin"
		fi
		NUM=1
		if [ -n "$(cat $C_ZT_LOG_DIR/controllogin/control | grep $MACS)" ];then
			NUM="$(cat $C_ZT_LOG_DIR/controllogin/control | grep $MACS | cut -d' ' -f2)"
			NUM=$(($NUM+1))
		fi
		if [ "$NUM" == "1" ];then
			$C_ZT_BIN_DIR/zt "Aggiungi" "$MACS $NUM $USERNAME_LOGIN" "$C_ZT_LOG_DIR/controllogin/control"
		else
			$C_ZT_BIN_DIR/zt "AddNumLogin" "$MACS" "$NUM" "$USERNAME_LOGIN"
		fi
		if [ "$NUM" -gt "$C_WAIT_LOGIN" ];then
			$C_ZT_BIN_DIR/zt "BlockMacLogin" "$MAC"
			NOTICE_LOCK="yes"
		else
			NUM_RIM=$(($C_WAIT_LOGIN-$NUM+1))
			echo "<br>&nbsp;<br>$L_AVAILABLE <br>$L_ATTEMPTS: $NUM_RIM "
		fi
	fi
	if [ -n "$NOTICE_LOCK" ];then
		SEC_WAIT=$(($C_WAIT_LOGIN_TIME*60))
		echo "<br>&nbsp;<br><font color=\"red\">$MAC</font><br>&nbsp;<br>$L_BLOCK_LOGIN<br>$L_FOR_MINUTES:"
		echo "<span id=\"countdown\" class=\"timer\"></span>
		<script>
		var seconds = \"$SEC_WAIT\";
		function secondPassed() {
			var minutes = Math.round((seconds - 30)/60);
			var remainingSeconds = seconds % 60;
			if (remainingSeconds < 10) {
				remainingSeconds = \"0\" + remainingSeconds;
			}
			document.getElementById('countdown').innerHTML = minutes + \":\" + remainingSeconds;
			if (seconds == 0) {
				clearInterval(countdownTimer);
				document.getElementById('countdown').innerHTML = \"0<br>&nbsp<br><form action="http://www.google.com" method="get"><input type="submit" name="CLOSE" class="bottone" value="$L_CLOSE"></form>\";
			} else {
				seconds--;
			}
		}
		var countdownTimer = setInterval('secondPassed()', 1000);
		</script>"
		echo "</td></tr></table></div>
		<div id=\"scritta\">$C_HOTSPOT_NAME</div>
		</body></html>"
		exit
	fi
fi
echo "<form action=\"http://www.google.com\" method=\"get\">
<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>"
echo "</td></tr></table></div>
<div id=\"scritta\">$C_HOTSPOT_NAME</div>
/body></html>"
