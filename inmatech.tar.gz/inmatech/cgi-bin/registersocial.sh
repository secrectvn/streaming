#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details...
#**********************************************************************

echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
POST=$(</dev/stdin)
if [ $POST != "" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR" | sed 's/%3A/:/g')\"
		[ "$NOMEVAR" == "USERNAME" ] && USERNAME=$(echo "$USERNAME" | sed 's/ //g' | tr '[:upper:]' '[:lower:]')
	done
fi
PL="$PASSWORD"
if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
source /DB/apache2/cgi-bin/zerotruth/functions.sh

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>

<script>
/*
/*
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Copyright (C) Paul Johnston 1999 - 2000.
 * Updated by Greg Holt 2000 - 2001.
 * See http://pajhome.org.uk/site/legal.html for details.
 */

var hex_chr = "0123456789abcdef";
function rhex(num)
{
  str = "";
  for(j = 0; j <= 3; j++)
    str += hex_chr.charAt((num >> (j * 8 + 4)) & 0x0F) +
           hex_chr.charAt((num >> (j * 8)) & 0x0F);
  return str;
}

function str2blks_MD5(str)
{
  nblk = ((str.length + 8) >> 6) + 1;
  blks = new Array(nblk * 16);
  for(i = 0; i < nblk * 16; i++) blks[i] = 0;
  for(i = 0; i < str.length; i++)
    blks[i >> 2] |= str.charCodeAt(i) << ((i % 4) * 8);
  blks[i >> 2] |= 0x80 << ((i % 4) * 8);
  blks[nblk * 16 - 2] = str.length * 8;
  return blks;
}
function add(x, y)
{
  var lsw = (x & 0xFFFF) + (y & 0xFFFF);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return (msw << 16) | (lsw & 0xFFFF);
}
function rol(num, cnt)
{
  return (num << cnt) | (num >>> (32 - cnt));
}
function cmn(q, a, b, x, s, t)
{
  return add(rol(add(add(a, q), add(x, t)), s), b);
}
function ff(a, b, c, d, x, s, t)
{
  return cmn((b & c) | ((~b) & d), a, b, x, s, t);
}
function gg(a, b, c, d, x, s, t)
{
  return cmn((b & d) | (c & (~d)), a, b, x, s, t);
}
function hh(a, b, c, d, x, s, t)
{
  return cmn(b ^ c ^ d, a, b, x, s, t);
}
function ii(a, b, c, d, x, s, t)
{
  return cmn(c ^ (b | (~d)), a, b, x, s, t);
}

function calcMD5(str)
{
  x = str2blks_MD5(str);
  a =  1732584193;
  b = -271733879;
  c = -1732584194;
  d =  271733878;

  for(i = 0; i < x.length; i += 16)
  {
    olda = a;
    oldb = b;
    oldc = c;
    oldd = d;

    a = ff(a, b, c, d, x[i+ 0], 7 , -680876936);
    d = ff(d, a, b, c, x[i+ 1], 12, -389564586);
    c = ff(c, d, a, b, x[i+ 2], 17,  606105819);
    b = ff(b, c, d, a, x[i+ 3], 22, -1044525330);
    a = ff(a, b, c, d, x[i+ 4], 7 , -176418897);
    d = ff(d, a, b, c, x[i+ 5], 12,  1200080426);
    c = ff(c, d, a, b, x[i+ 6], 17, -1473231341);
    b = ff(b, c, d, a, x[i+ 7], 22, -45705983);
    a = ff(a, b, c, d, x[i+ 8], 7 ,  1770035416);
    d = ff(d, a, b, c, x[i+ 9], 12, -1958414417);
    c = ff(c, d, a, b, x[i+10], 17, -42063);
    b = ff(b, c, d, a, x[i+11], 22, -1990404162);
    a = ff(a, b, c, d, x[i+12], 7 ,  1804603682);
    d = ff(d, a, b, c, x[i+13], 12, -40341101);
    c = ff(c, d, a, b, x[i+14], 17, -1502002290);
    b = ff(b, c, d, a, x[i+15], 22,  1236535329);

    a = gg(a, b, c, d, x[i+ 1], 5 , -165796510);
    d = gg(d, a, b, c, x[i+ 6], 9 , -1069501632);
    c = gg(c, d, a, b, x[i+11], 14,  643717713);
    b = gg(b, c, d, a, x[i+ 0], 20, -373897302);
    a = gg(a, b, c, d, x[i+ 5], 5 , -701558691);
    d = gg(d, a, b, c, x[i+10], 9 ,  38016083);
    c = gg(c, d, a, b, x[i+15], 14, -660478335);
    b = gg(b, c, d, a, x[i+ 4], 20, -405537848);
    a = gg(a, b, c, d, x[i+ 9], 5 ,  568446438);
    d = gg(d, a, b, c, x[i+14], 9 , -1019803690);
    c = gg(c, d, a, b, x[i+ 3], 14, -187363961);
    b = gg(b, c, d, a, x[i+ 8], 20,  1163531501);
    a = gg(a, b, c, d, x[i+13], 5 , -1444681467);
    d = gg(d, a, b, c, x[i+ 2], 9 , -51403784);
    c = gg(c, d, a, b, x[i+ 7], 14,  1735328473);
    b = gg(b, c, d, a, x[i+12], 20, -1926607734);

    a = hh(a, b, c, d, x[i+ 5], 4 , -378558);
    d = hh(d, a, b, c, x[i+ 8], 11, -2022574463);
    c = hh(c, d, a, b, x[i+11], 16,  1839030562);
    b = hh(b, c, d, a, x[i+14], 23, -35309556);
    a = hh(a, b, c, d, x[i+ 1], 4 , -1530992060);
    d = hh(d, a, b, c, x[i+ 4], 11,  1272893353);
    c = hh(c, d, a, b, x[i+ 7], 16, -155497632);
    b = hh(b, c, d, a, x[i+10], 23, -1094730640);
    a = hh(a, b, c, d, x[i+13], 4 ,  681279174);
    d = hh(d, a, b, c, x[i+ 0], 11, -358537222);
    c = hh(c, d, a, b, x[i+ 3], 16, -722521979);
    b = hh(b, c, d, a, x[i+ 6], 23,  76029189);
    a = hh(a, b, c, d, x[i+ 9], 4 , -640364487);
    d = hh(d, a, b, c, x[i+12], 11, -421815835);
    c = hh(c, d, a, b, x[i+15], 16,  530742520);
    b = hh(b, c, d, a, x[i+ 2], 23, -995338651);

    a = ii(a, b, c, d, x[i+ 0], 6 , -198630844);
    d = ii(d, a, b, c, x[i+ 7], 10,  1126891415);
    c = ii(c, d, a, b, x[i+14], 15, -1416354905);
    b = ii(b, c, d, a, x[i+ 5], 21, -57434055);
    a = ii(a, b, c, d, x[i+12], 6 ,  1700485571);
    d = ii(d, a, b, c, x[i+ 3], 10, -1894986606);
    c = ii(c, d, a, b, x[i+10], 15, -1051523);
    b = ii(b, c, d, a, x[i+ 1], 21, -2054922799);
    a = ii(a, b, c, d, x[i+ 8], 6 ,  1873313359);
    d = ii(d, a, b, c, x[i+15], 10, -30611744);
    c = ii(c, d, a, b, x[i+ 6], 15, -1560198380);
    b = ii(b, c, d, a, x[i+13], 21,  1309151649);
    a = ii(a, b, c, d, x[i+ 4], 6 , -145523070);
    d = ii(d, a, b, c, x[i+11], 10, -1120210379);
    c = ii(c, d, a, b, x[i+ 2], 15,  718787259);
    b = ii(b, c, d, a, x[i+ 9], 21, -343485551);

    a = add(a, olda);
    b = add(b, oldb);
    c = add(c, oldc);
    d = add(d, oldd);
  }
  return rhex(a) + rhex(b) + rhex(c) + rhex(d);
}
</script>
<script>
	function Modulo()
	{
		var a = Math.ceil(Math.random() * 10)+ '';
		var b = Math.ceil(Math.random() * 10)+ '';
		var c = Math.ceil(Math.random() * 10)+ '';
		var d = Math.ceil(Math.random() * 10)+ '';
		var e = Math.ceil(Math.random() * 10)+ '';
		var f = Math.ceil(Math.random() * 10)+ '';
		var g = Math.ceil(Math.random() * 10)+ '';
		var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
		document.getElementById("txtCaptcha").value = code
//		var controlemail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

	}
	function Control(){
		var USERNAME = document.getElementById("USERNAME").value;
		var CONTROLEMAIL = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if (!CONTROLEMAIL.test(USERNAME)) {
			alert("Email: $L_MISSING_DATA");
			document.registersocial.USERNAME.focus();
			return false;
		}
		var PASSWORD = document.getElementById("PASSWORD").value;
		var PASSWORDLOGIN = calcMD5(PASSWORD);
		var tag = document.getElementById("PASS");
		var el = document.createElement('input');
		el.id = tag.id;
		el.name = tag.name;
		el.value = PASSWORDLOGIN;
		el.type = tag.type;
		tag.parentNode.insertBefore(el, tag);
		tag.parentNode.removeChild(tag);
		var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
		var str2 = removeSpaces(document.getElementById('txtInput').value);
		if ((USERNAME == "") || (USERNAME == "undefined")) {
			alert("Email: $L_MISSING_DATA");
			document.registersocial.USERNAME.focus();
			return false;
		}
		else if ((PASSWORD == "") || (PASSWORD == "undefined")) {
			alert("PASSWORD: $L_MISSING_DATA");
			document.registersocial.PASSWORD.focus();
			return false;
		}
		else if (str1 != str2)	{
			alert("$L_CAPTCHA_ERROR");
			document.registersocial.txtInput.value = "";
			document.registersocial.txtInput.focus();
			return false;
		}
		else
		{

			document.registersocial.action = "registersocial.sh";
			document.registersocial.method = "POST";
			document.registersocial.submit();
		}
	}
	function removeSpaces(string)
	{
		return string.split(' ').join('');
	}
</script>
</head>
<body onload="Modulo()">

EOF

if [ -z "$C_AUTO_REGISTER" ];then
	exit
fi

echo "<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>
<div id=\"scritta\">$L_SELF_REGISTER</div>"

date2stamp () {
  date --utc --date "$1" +%s
}

stamp2date (){
  date --utc --date "1970-01-01 $1 sec" "+%Y-%m-%d %T"
}
dateDiff (){
  case $1 in
		-s)  sec=1;   shift;;
		-m)  sec=60;   shift;;
		-h)  sec=3600;  shift;;
		-d)  sec=86400; shift;;
		*)  sec=86400;;
	esac
	dte1=$(date2stamp $1)
	dte2=$(date2stamp $2)
	diffSec=$((dte2-dte1))
	if ((diffSec < 0)); then abs=-1; else abs=1; fi
	echo $((diffSec/sec*abs))
}
error () {
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\"><font color=\"red\" size=\"3\">$1</font><p>
	<p><form action=\"registersocial.sh\" method=\"post\">
	<input type=\"hidden\" name=\"social\" value=\"$social\">
	<input type=\"submit\" name=\"$L_GO_BACK\"
	class=\"bottone\" value=\"$L_GO_BACK\"></form>
	</td></tr></table>
	</div>
	</body></html>"
	exit
}
if [ -n "$CLOSE" ];then
	if [ -z "$NG" ];then
		if [ "$CSL" == "yes" ];then
			USERNAME="$( echo "$USERNAME" | $C_ZT_BIN_DIR/base64)"
			PASSWORD="$( echo "$PL" | $C_ZT_BIN_DIR/base64)"
			echo "<script>window.opener.location = \"http://zerotruth.net/?LoginUser=$USERNAME&pass=$PASSWORD\";</script>"
		fi
		echo "<script>setTimeout('window.close()', 500);</script>"
	else
		echo "<script>window.location = \"http://www.google.com\"</script>"
	fi
	exit
fi

MAC=$(arp -an | grep $REMOTE_ADDR | awk '{split ($0, a, " ");print a['4']}')
MAC=$(echo "$MAC" | tr '[:lower:]' '[:upper:]')
if [ -n "$(cat $C_ZT_CONF_DIR/macblocked | grep $MAC)" ];then
	CONTROL="ok"
	BLOCK_MAC="$MAC"
fi
if [ -n "$C_WAIT_REGISTER" ];then
	if [[ -n "$(cat $C_ZT_CONF_DIR/banmac | grep $MAC)" || -n "$(cat $C_ZT_CONF_DIR/macblocked | grep $MAC)" ]];then
		CONTROL="ok"
		BLOCK_MAC="$MAC"
	fi
fi
DAYS=$(date +%w)
ORAS=$(date +%H)
MINS=$(date +%M)
ORAMIN=$ORAS$MINS
ORAMIN=$(echo $ORAMIN | awk '{print $1 + 0}')
if [[ -n "$CONTROL" || -n "$NEW_REG" ]];then
	 if [ -n "$BLOCK_MAC" ];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<p><font color=\"red\">$L_BLOCK_MAC<p>$BLOCK_MAC</font><p>
		<form action=\"registersocial.sh\" method=\"post\">
		<input type=\"hidden\" name=\"NG\" value=\"$NEW_REG\">
		<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
		</td></tr></table>
		</div>
		</body></html>"
		exit
	fi
	if [ -n "$USERNAME" ];then
		USERNAME_LOGIN="$USERNAME"
		PASSWORD_LOGIN="$PASSWORDLOGIN"
		CONTROL_LOGIN=$($C_ZT_BIN_DIR/zt "RegisterSocial" "$social" "$USERNAME" "$PASSWORD")
		if [ "$CONTROL_LOGIN" == "yes" ];then
			ldap_search_people "mail=$USERNAME"
			ldap_search_radius "$USERNAME"
			if [ -n "$USERNAME" ];then
				PASSWORD="$(echo "$PASSWORD" | cut -d'-' -f1)"
				IPCP="$(cat $C_SYSTEM/cp/Auth/Custom/IP)"
				echo "<div id=\"paginaprivacy\">
				<table class=\"tabella\" align=\"center\">
				<tr><td align=\"center\">
				<p><font color=\"red\">$L_EMAIL_PRE</font><p>
				<form name=\"data\" action=\"registersocial.sh\" method=\"post\">
				<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
				</td></tr></table>
				</div>
				</body></html>"
				exit
			else
				NEW_USER="yes"
			fi
		else
			echo "<div id=\"paginaprivacy\">
			<table class=\"tabella\" align=\"center\">
			<tr><td align=\"center\">
			<p><font color=\"blue\">$social</font><p><font color=\"red\">$L_LOGIN_INVALID</font><p>
			<form action=\"registersocial.sh\" method=\"post\">
			<input type=\"hidden\" name=\"social\" value=\"$social\">
			<input type=\"submit\" name=\"reload\" class=\"bottone\" value=\"$L_CLOSE\"></form>
			</td></tr></table>
			</div>
			</body></html>"
			exit
		fi
	fi

	if [ -n "$NEW_USER" ];then
		USERNAME="$(echo $USERNAME_LOGIN | sed 's/[^[:alnum:]]//g' | tr A-Z a-z )"
		EMAIL="$USERNAME_LOGIN"
		PHONE="?"
		NAME="$L_ANONYMOUS"
		LAST_NAME="$L_ANONYMOUS"
		if [ -n "$(cat $C_ZT_CONF_DIR/privacy)" ];then
			TEXT_PRIVACY=$(cat $C_ZT_CONF_DIR/privacy )
			echo "<div id=\"paginaprivacy\">
			<table class=\"tabella\" align=\"center\">
			<tr><td align=\"center\">
			<p class=\"privacy\">$TEXT_PRIVACY</p>
			<form method=\"POST\" action=\"registersocial.sh\">
			$L_AGREE <input name=\"ACCEPT\" type=\"checkbox\"><p>
			<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
			<input type=\"hidden\" name=\"NAME\" value=\"$L_ANONYMOUS\">
			<input type=\"hidden\" name=\"LAST_NAME\" value=\"$L_ANONYMOUS\">
			<input type=\"hidden\" name=\"EMAIL\" value=\"$EMAIL\">
			<input type=\"hidden\" name=\"CONTROL_ACCEPT\" value=\"OK\">
			<input type=\"hidden\" name=\"CONTROL_NEW\" value=\"$NEW_REG\">
			<input type=\"hidden\" name=\"social\" value=\"$social\">
			<input type=\"hidden\" name=\"PASSWORD_LOGIN\" value=\"$PASSWORDLOGIN\">
			<input type=\"hidden\" name=\"PASSWORD\" value=\"$PL\">
			<input type=\"submit\" name=\"CONTINUE\" class=\"bottone\" value=\"$L_CONTINUE\"></form>
			</td></tr></table>
			</div>
			</body></html>"
			exit
		else
			CONTROL_ACCEPT="OK"
			CONTROL_NEW="$NEW_REG"
			ACCEPT="on"
		fi
	fi
fi

if [[ -n "$CONTROL_ACCEPT" && "$ACCEPT" == "on" ]] || [ -n "$CONTROL_PAY" ];then
	CHARGE_TYPE=$(cat $C_CLASSES_DIR/$C_AR_CLASS/ChargeType)
	if [[ "$CHARGE_TYPE" == "pre" && -z "$CONTROL_PAY"  && -n "$C_ACTIVE_PP" ]];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">"
		$C_ZT_BIN_DIR/zt "Salva" "USER $USERNAME" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "Aggiungi" "NAME $NAME" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "Aggiungi" "LAST_N $LAST_NAME" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "Aggiungi" "EMAIL $EMAIL" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "Aggiungi" "PHONE $PHONE" "$C_ZT_DIR/tmp/lock_pay_$USERNAME"
		$C_ZT_BIN_DIR/zt "ConnectPP" "$REMOTE_ADDR" "$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)" "yes"
		cat $C_ZT_CONF_DIR/ppbutton | sed "s/<input type=\"image/<input type=\"hidden\" name=\"custom\" value=\"$USERNAME\"> <input type=\"image/g"
		echo "</td></tr></table>
		</div>
		</body></html>"
		exit
	fi
	if [ -n "$CONTROL_PAY" ];then
		USERNAME=$(cat $C_ZT_DIR/tmp/lock_pay_$USERNAME_LOCK | grep USER | awk '{print $2}')
		NAME=$(cat $C_ZT_DIR/tmp/lock_pay_$USERNAME_LOCK | grep NAME | awk '{print $2}')
		LAST_NAME=$(cat $C_ZT_DIR/tmp/lock_pay_$USERNAME_LOCK | grep LAST_N | awk '{print $2}')
		EMAIL=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep EMAIL | awk '{print $2}')
		PHONE=$(cat $C_ZT_DIR/tmp/lock_pay_$USERNAME_LOCK | grep PHONE | awk '{print $2}')
		if [[ "$CONTROL_PAY" == "Completed" && "$ID_PAY" == $(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep TXN_ID | awk '{print $2}') ]];then
			[ ! -f $C_ZT_LOG_DIR/pp/payments ] && touch $C_ZT_LOG_DIR/pp/payments
			DATAD=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep PAYMENT_DATE | sed "s/PAYMENT_DATE //g")
			DATAH=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep PAYMENT_HOUR | awk '{print $2}')
			CREDIT=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep AMMOUNT | awk '{print $2}')
			TID=$(cat $C_ZT_DIR/tmp/lock_pay_$USER_LOCK | grep TXN_ID | awk '{print $2}')
			$C_ZT_BIN_DIR/zt "Aggiungi"	"$USER_LOCK+$DATAD+$DATAH+$CREDIT+$TID" "$C_ZT_LOG_DIR/pp/payments"
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/lock_pay_$USER_LOCK"
		else
			$C_ZT_BIN_DIR/zt "Cancella" "$C_ZT_DIR/tmp/lock_pay_$USER_LOCK"
			error "NOT APPROVED"
			exit
		fi
		$C_ZT_BIN_DIR/zt "ConnectPP" "$REMOTE_ADDR" "$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)" "no"
		$C_ZT_BIN_DIR/zt "KillCP" "$REMOTE_ADDR"
	fi

	if [ -z "$CONTROL_NEW" ];then
	#	PASSWORD=$($C_ZT_BIN_DIR/zt "MD5" "$PASSWORD_LOGIN")
	#	PASSWORD=$(echo "$PASSWORD" | awk '{print $1}')
		PASSWORD="$PASSWORD_LOGIN"
		UIDN=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uidNumber | sed -n '/uidNumber:/p' | awk '{ print $2 }' | sort -n | tail -1 )
		UIDNUMBER=$(($UIDN+1))
	fi
	TODAY=$(dateDiff -d "1970-01-01" "$(date +%Y)-$(date +%m)-$(date +%d)")
	if [ -z "$C_AR_EXPIRE" ];then
		C_AR_EXPIRE=24836
	else
		SHADOWEXPIRE=$C_AR_EXPIRE
		DIFF_DATE=$(($SHADOWEXPIRE-$TODAY))
		AR_YEAR=$(date +%Y --date="+$DIFF_DATE days")
		AR_MONTH=$(date +%m --date="+$DIFF_DATE days")
		AR_DAY=$(date +%d --date="+$DIFF_DATE days")
		DATEK5="$AR_YEAR-$AR_MONTH-$AR_DAY"
	fi
	if [ -n "$C_AR_EXPIRE_DAYS" ];then
	 	AR_YEAR=$(date +%Y --date="+$C_AR_EXPIRE_DAYS days")
		AR_MONTH=$(date +%m --date="+$C_AR_EXPIRE_DAYS days")
		AR_DAY=$(date +%d --date="+$C_AR_EXPIRE_DAYS days")
		SHADOWEXPIRE=$(dateDiff -d "1970-01-01" "$AR_YEAR-$AR_MONTH-$AR_DAY")
		DATEK5="$AR_YEAR-$AR_MONTH-$AR_DAY"
	fi
	PASSWORD_ORI="$PASSWORD"
	CLASS="$C_AR_CLASS"
	INFO="autoregister $social"
	if [ -z "$CONTROL_NEW" ];then
		ldap_add_people
	else
		ldap_modify_people "validity shadowExpire"
	fi
	if [[ -n "$CONTROLMODIFY" || -n "$CONTROLADD" ]]; then
		error "$L_PROBLEM_INSERTING"
		exit
	fi
	if [ -z "$CONTROL_NEW" ];then
		ldap_add_radius
	else
		ldap_modify_radius "sn radiusUserCategory"
	fi
	if [[ -n "$CONTROLMODIFY" || -n "$CONTROLADD" ]]; then
		/usr/local/bin/ldapdelete -c -x -D "$C_LDAPMANAGER,$C_LDAPBASE" -w $C_LDAPROOT "uid=$USERNAME,ou=People,$C_LDAPBASE" 2> /dev/null > /dev/null
		error "$L_PROBLEM_INSERTING"
		exit
	fi
	$C_ZT_BIN_DIR/zt "ControlAcct" "$USERNAME"
	$C_ZT_BIN_DIR/zt "ControlLimits" "$USERNAME"
	if [ -z "$CONTROL_NEW" ];then
		$C_ZT_BIN_DIR/zt "AddK5" "$PASSWORD" "$USERNAME" "$DATEK5"
	else
		$C_ZT_BIN_DIR/zt "UpdateK5" "$PASSWORD" "$USERNAME" "$DATEK5"
		$C_ZT_BIN_DIR/zt "Salva" "" "$C_ACCT_DIR/entries/$USERNAME/MB"
		$C_ZT_BIN_DIR/zt "Salva" "" "$C_ACCT_DIR/entries/$USERNAME/Time"
	fi
	if [ -n "$CREDIT" ];then
		if [ $(cat $C_ACCT_DIR/credits/$USERNAME/Credit) ];then
			CREDITES=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit | awk '{printf("%.2f\n", $0)}')
		else
			CREDITES=0
		fi
		CREDIT=$(echo "$CREDITES+$CREDIT" | $C_ZT_BIN_DIR/bc | awk '{printf("%.2f\n", $0)}')
		if [ ! -d "$C_ACCT_DIR/credits/$USERNAME" ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ACCT_DIR/credits/$USERNAME"
		fi
			$C_ZT_BIN_DIR/zt "Salva" "$CREDIT" "$C_ACCT_DIR/credits/$USERNAME/Credit"
	fi
	if [ $SHADOWEXPIRE == 24836 ];then
		EXPIRE=$L_NO_LIMIT
	else
		if [ "$C_FORM_DATE" == "ita" ];then
			EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%d/%m/%Y)
		else
			EXPIRE=$(date -d "1970-01-01 $SHADOWEXPIRE days" +%Y/%m/%d)
		fi
	fi
	if [ "$C_FORM_DATE" == "ita" ];then
		DATE_CREATED=$(date +%d/%m/%Y)
	else
		DATE_CREATED=$(date +%Y/%m/%d)
	fi

	TEXT_EMAIL="$(cat $C_ZT_CONF_DIR/emailh)\n"
	TEXT_EMAIL="$TEXT_EMAIL\n$L_USERNAME: $EMAIL\n$L_PASSWORD:  $social Password"
	if [ -n "$CREDIT" ];then
		TEXT_EMAIL="$TEXT_EMAIL\n$L_CREDIT: $CREDIT"
	fi
	TEXT_EMAIL="$TEXT_EMAIL\n$L_CLASS: $C_AR_CLASS\n$L_CREATED: $DATE_CREATED\n$L_EXPIRY: $EXPIRE"
	CLASS="$C_AR_CLASS"
	limituser "$USERNAME"
	TEXT_EMAIL="$TEXT_EMAIL\n$L_DAYS: $USERDAYS\n$L_LIMIT $L_HOURS: $USERTIME"
	[ -n "$USERHOURSDAY" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_DMAX_HOURS: $USERHOURSDAY"
	[ -n "$USERHOURSMONTH" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_MMAX_HOURS: $USERHOURSMONTH"
	[ -n "$USERMBDAY" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_DMAX_MB: $USERMBDAY"
	[ -n "$USERMBMONTH" ] && TEXT_EMAIL="$TEXT_EMAIL\n$L_MMAX_MB: $USERMBMONTH"
	TEXT_EMAIL="$TEXT_EMAIL\n\n$(cat $C_ZT_CONF_DIR/emailf)"
	TEXT_EMAIL=$(urlencode "$TEXT_EMAIL")
	TEXT_EMAIL=$($C_ZT_BIN_DIR/convplain "$TEXT_EMAIL")
	$C_ZT_BIN_DIR/zt "Email" "$C_HOTSPOT_NAME" "$TEXT_EMAIL" "$EMAIL" 2>/dev/null >/dev/null

	if [ -n "$C_WAIT_REGISTER" ];then
		if ! [ -d $C_ZT_LOG_DIR/controlregister ];then
			$C_ZT_BIN_DIR/zt "CreaCartella" "$C_ZT_LOG_DIR/controlregister"
		fi
		 $C_ZT_BIN_DIR/zt "Aggiungi" "$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4) $(date +%s)" "$C_ZT_LOG_DIR/controlregister/control"
	fi
	POST_REGISTRATION="$(cat /Database/var/register/system/cp/Auth/Custom/PostRegistration | sed '/\\/s///g')"
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<p class=\"privacy\">$POST_REGISTRATION</p>
	<form action=\"registersocial.sh\" method=\"post\">
	<input type=\"hidden\" name=\"NG\" value=\"$CONTROL_NEW\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$EMAIL\">
	<input type=\"hidden\" name=\"PASSWORD\" value=\"$PL\">
	<input type=\"hidden\" name=\"CSL\" value=\"yes\">
	<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
	</td></tr></table>
	</div>
	</body></html>"
	MAC=$(arp -an | grep $REMOTE_ADDR | awk '{split ($0, a, " ");print a['4']}')
	$C_ZT_BIN_DIR/zt "RimuoviRiga" "$MAC" "$C_ZT_CONF_DIR/tmp_banmac"
	CHARGE_TYPE=$(cat $C_CLASSES_DIR/$C_AR_CLASS/ChargeType)
	if [ "$CHARGE_TYPE" == "pre" ];then
		$C_ZT_BIN_DIR/zt "ConnectPP" "$REMOTE_ADDR" "$(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)" "no"
		$C_ZT_BIN_DIR/zt "KillCP" "$REMOTE_ADDR"
	fi
	if [ -n "$C_NOT_EMAIL_ADD_USER" ] && [ -n "$C_ADMIN_EMAIL" ];then
		$C_ZT_BIN_DIR/zt "Email" "$L_NAME_HOTSPOT: $C_HOTSPOT_NAME" "$TEXT_EMAIL" "$C_ADMIN_EMAIL"
	fi
	if [ "$C_NOT_SMS_ADD_USER" == "on" ] && [ -n "$C_ADMIN_PHONE" ];then
		TEXT_SMS="$C_HOTSPOT_NAME: $L_USERADD $USERNAME $NAME $LAST_NAME ($L_SELF_REGISTER)"
		$C_ZT_BIN_DIR/zt "InviaSms" "$C_SMS_PROVIDER" "$C_ADMIN_PHONE" "$TEXT_SMS" "" "credit"
	fi
	exit
fi
#echo "<font size=\"3\" color=\"blue\">$social Login</font>"
echo "<div id=\"paginareg\">
<table class=\"tabellareg\" align=\"center\">
<tr><td align=\"center\">"
if [ -n "$C_WAIT_REGISTER" ];then
	LINE=$(cat $C_ZT_LOG_DIR/controlregister/control | grep $(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4) | tail -1)
	if [ -n "$LINE" ];then
		TIME_LAST=$(echo -e "$LINE" | cut -d' ' -f2)
		TIME_NOW=$(date +%s)
		TIME_PAST=$(($TIME_NOW-$TIME_LAST))
		TIME_WAITING=$(($C_WAIT_REGISTER*60))
		if [ "$TIME_WAITING" -gt "$TIME_PAST" ];then
			WAIT=$(($TIME_WAITING-$TIME_PAST))
			WAITM=$(($WAIT/60))
			[ "$WAITM" == 0 ] && WAITM="$L_LESS_MIN"
			echo "<p>&nbsp;<p>
			<font color=\"blue\">MAC address: $(arp -an | grep $REMOTE_ADDR | cut -d' ' -f4)</font> <p>
			<font color=\"red\" size=\"4\">$L_NO_SERVICE<br>$L_FOR_MINUTES: $WAITM</font>
			<form action=\"registersocial.sh\" method=\"post\">
			<input type=\"hidden\" name=\"NG\" value=\"$NEW_REG\">
			<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>"
			NEW_REG="no"
			exit
		fi
	fi
fi

if [ -z "$CONTROL_NEW_REGISTER" ];then
	echo "<img src=\"/images/template/$social.png\" style=\"width: 70%\"><br><font size=\"3\" color=\"blue\">$social Login</font><br>&nbsp;<br>"
	echo "<form name=\"registersocial\">
	<table>"
	echo "<tr><td>Email:</td>
	<td colspan=\"2\"><input class=\"input\" id=\"USERNAME\" type=\"text\" name=\"USERNAME\" value=\"$USERNAME\"></td></tr>"
	echo "<tr><td>Password:</td>
	<td colspan=\"2\"><input class=\"input\" id=\"PASSWORD\" name=\"PASSWORD\" type=\"password\"  value=\"\"></td></tr>
	</table>
	<input type=\"hidden\" id=\"PASS\" name=\"PASSWORDLOGIN\" value=\"\">
	<input type=\"hidden\" name=\"CONTROL\" value=\"OK\">
	<input type=\"hidden\" name=\"social\" value=\"$social\">
	$L_COPY_CATPCHA<br>
	<input readonly type=\"text\" id=\"txtCaptcha\"
	style=\"background-image:url(/images/template/imgcaptcha.png); text-align:center; border:none;
	font-weight:bold; font-size: 16px;\"><br>
	<input type=\"tel\" style=\"text-align: center\" id=\"txtInput\">
	<p><input type=\"button\" name=\"SALVA\" class=\"bottone\" value=\"$L_SENDS\" onclick=\"Control();\"></form>"
else
	ldap_search_people "uid=$USERNAME_LOGIN"
	ldap_search_radius "$USERNAME_LOGIN"
	PREFIX="${PHONE:0:2}"
	PHONE="${PHONE:2}"
	echo "<form name=\"registernew\" action=\"registersocial.sh\" method=\"POST\">
	<table>
	<tr><td>$L_USER_NAME:</td>
	<td colspan=\"2\"><input class=\"input\"  readonly type=\"text\" name=\"USERNAME\" value=\"$USERNAME\"></td></tr>
	<tr><td>$L_NAME:</td>
	<td colspan=\"2\"><input class=\"input\"  readonly name=\"NAME\" type=\"text\"  value=\"$NAME\"></td></tr>
	<tr><td>$L_LAST_NAME:</td>
	<td colspan=\"2\"><input class=\"input\"  readonly type=\"text\" name=\"LAST_NAME\" value=\"$LAST_NAME\"></td></tr>
	<tr><td>$L_EMAIL:</td>
	<td colspan=\"2\"><input class=\"input\"  readonly type=\"text\" name=\"EMAIL\" value=\"$EMAIL\"></td></tr>
	<tr><td>$L_PHONE:</td>
	<td><input class=\"inputprefix\"  type=\"text\" readonly size=\"2\" name=\"PREFIX\" value=\"$PREFIX\"></td>
	<td><input class=\"inputphone\" type=\"text\"  readonly size=\"2\" name=\"PHONE\" value=\"$PHONE\"></td>
	</tr>
	</table>
	<input type=\"hidden\" name=\"PASSWORD\" value=\"$PASSWORD\">
	<input type=\"hidden\" name=\"NEW_REG\" value=\"OK\">
	<p><input type=\"submit\" name=\"SALVA\" class=\"bottone\" value=\"$L_SENDS\"></form>"
fi
echo "</td></tr>
</table>
</div>
</body>
</html>"
