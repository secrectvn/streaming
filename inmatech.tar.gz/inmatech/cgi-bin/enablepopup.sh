#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details...
#***************t*******************************************************

echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
source /DB/apache2/cgi-bin/zerotruth/language/$C_LANGUAGE/$C_LANGUAGE.sh

POST=$(</dev/stdin)
if [ $POST != "" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR" | sed 's/%3A/:/g')\"
		[ "$NOMEVAR" == "USERNAME" ] && USERNAME=$(echo "$USERNAME" | sed 's/ //g' | tr '[:upper:]' '[:lower:]')
	done
fi

if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
	REDIRECT="$(echo $REDIRECT | cut -d'/' -f3)"
fi

if [ -n "$CLOSE" ];then
	echo "<script>window.location.href = \"http://$REDIRECT\";</script>"
fi

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>
</head><body>
EOF
echo "<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>
<div id=\"scritta\">$L_ENABLE_POPUP</div>

<div id=\"paginaprivacy\">
<table class=\"tabella\" align=\"center\">
<tr><td align=\"center\">
<p>$L_ENABLE_POPUP_TEXT</p>
<form action=\"enablepopup.sh\" method=\"post\">
<input type=\"hidden\" name=\"REDIRECT\" value=\"$REDIRECT\">
<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
</td></tr>
</table>
</div>
</body>
</html>"
