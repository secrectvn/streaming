#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config

if [ -n "$QUERY_STRING" ];then
	PHONE=$(echo "$QUERY_STRING" | cut -d"=" -f2 | cut -d"+" -f1 )
	PHONE=$(echo "$PHONE" | sed 's/^\+//g' | sed 's/^0//g' | sed 's/^0//g' )
	CONTROL=$(echo "$QUERY_STRING" | cut -d"=" -f2 | cut -d"+" -f2)
	[ "$CONTROL" != "$C_PASS_ASTERISK" ] && exit
	QUERY=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" telephoneNumber=*$PHONE uid)
	USERNAME=$(echo "$QUERY" | grep -e '^uid: ' | sed 's/^uid: //g')
	if [ -n "$USERNAME" ];then
		$C_ZT_BIN_DIR/zt "Salva" "yes" "/tmp/${USERNAME}passasterisk"
		echo "yes"
	else
		echo "no"
	fi
	exit
fi
POST=$(</dev/stdin)
if [ $POST != "" ];then
	NUM=$(echo $POST | grep -o "=" | wc -l)
	for i in $(seq 1 $NUM);do
		NOMEVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f1)
		VALVAR=$(echo $POST | cut -d'&' -f$i | cut -d'=' -f2)
		eval $NOMEVAR=\"$($C_ZT_BIN_DIR/convnum "$VALVAR" | sed 's/%3A/:/g')\"
	done
fi
if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh
source /DB/apache2/cgi-bin/zerotruth/functions.sh

cat << EOF
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, user-scrollbar=no">
<link href="/css/template/zt_login_mobile.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 0px) and (max-width: 320px)" >
<link href="/css/template/zt_login_tablet.css" rel="stylesheet" type="text/css" media="only screen and (min-width: 321px) and (max-width: 768px)" >
<script>
  var zt_login = document.createElement("link");
  zt_login.setAttribute("rel", "stylesheet");
  zt_login.setAttribute("type", "text/css");
  zt_login.setAttribute("href", "/css/template/zt_login.css");
  if ( navigator.userAgent.search("MSIE [2-9]{1}\.") > 0 ) {
    zt_login.setAttribute("media", "all");
  } else {
    zt_login.setAttribute("media", "only screen and (min-width: 769px)");
  }
  document.getElementsByTagName("head")[0].appendChild(zt_login);
</script>
EOF
echo "<script type=\"text/javascript\">
function DrawCaptcha(){
	var a = Math.ceil(Math.random() * 10)+ '';
	var b = Math.ceil(Math.random() * 10)+ '';
	var c = Math.ceil(Math.random() * 10)+ '';
	var d = Math.ceil(Math.random() * 10)+ '';
	var e = Math.ceil(Math.random() * 10)+ '';
	var f = Math.ceil(Math.random() * 10)+ '';
	var g = Math.ceil(Math.random() * 10)+ '';
	var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
	document.getElementById(\"txtCaptcha\").value = code
}
function ValidCaptcha(){
	var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
	var str2 = removeSpaces(document.getElementById('txtInput').value);
	if (str1 == str2)
	{
		document.register.method = \"post\";
		document.register.action = \"forgotasterisk.sh\";
		document.register.submit();
	}
	else
	{
		alert(\"$L_CAPTCHA_ERROR.\");
		document.register.method = \"get\";
		document.register.action = \"forgotasterisk.sh\";
	}
}
function removeSpaces(string){
	return string.split(' ').join('');
}
</script>"
echo "</head><body onload=\"DrawCaptcha();\">
<p>
<div id=\"scheda\"></div>
<div id=\"logouser\"></div>"
POST=$(</dev/stdin)

if [ -n "$CLOSE" ];then
	$C_ZT_BIN_DIR/zt "Cancella" "/tmp/${USER}passasterisk"
	echo "<script>setTimeout('window.close()', 4)</script>"
fi
if [ $POST != "" ];then
	if [ -z "$USER" ];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<font color=\"red\">$L_MISSING_DATA</font><p>
		<p><form action=\"forgotasterisk.sh\" method=\"get\"><input type=\"submit\" name=\"$L_GO_BACK\" class=\"bottone\" value=\"$L_GO_BACK\"></form>
		</td></tr>
		</table>
		</div>
		<div id=\"scritta\">$L_REC_PASSWORD</div>
		</body></html>"
		exit
	fi
	LINE=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" "( & (uid=$USER)  (telephoneNumber=$PHONE))" uid givenName sn)
	USER_EX=$( echo "$LINE" |  grep -e '^uid: ' | sed 's/^uid: //g')
	NAME=$( echo "$LINE" | grep -e '^givenName: ' | sed 's/^givenName: //g')
	LAST_NAME=$( echo "$LINE" | grep -e '^sn: ' | sed 's/^sn: //g')
	if [ "$USER_EX" == "$USER" ];then
		RADIUS=$(/usr/local/bin/ldapsearch -xLLL -b "ou=Radius,$C_LDAPBASE" cn=$USER sn)
		PASSWORD=$(echo "$RADIUS" | grep -e '^sn: ' | sed 's/^sn: //g')
		PASSWORD=$(echo "$PASSWORD" | cut -d'-' -f1)
	else
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<font color=\"red\">$L_MISSING_USER kk</font><p>
		<p><form action=\"forgotasterisk.sh\" method=\"get\"><input type=\"submit\" name=\"$L_GO_BACK\" class=\"bottone\" value=\"$L_GO_BACK\"></form>
		</td></tr>
		</table>
		</div>
		<div id=\"scritta\">$L_REC_PASSWORD</div>
		</body></html>"
		exit
	fi
	if [ "$CONTROL" == "ASTERISK" ];then
		CPASSWORD="$(cat /tmp/${USER}passasterisk)"
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">"
		if [ "$CPASSWORD" == "yes" ];then
			PASSWORD="$(echo "$PASSWORD" | cut -d'-' -f1)"
			echo "<font color=\"blue\" size=\"4\">PASSWORD: $PASSWORD </font>
			<p>
			<form action=\"forgot.sh\" method=\"post\">
			<input type=\"hidden\" name=\"USER\" value=\"$USER\">
			<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>"
		else
			echo "<font color=\"blue\" size=\"4\">$L_ASTERISK_WAIT</font>
			<p>
			<form action=\"forgotasterisk.sh\" method=\"post\">
			<input type=\"hidden\" name=\"CONTROL\" value=\"ASTERISK\">
			<input type=\"hidden\" name=\"USER\" value=\"$USER\">
			<input type=\"hidden\" name=\"PHONE\" value=\"$PHONE\">
			<input type=\"submit\" name=\"CONTINUE\" class=\"bottone\" value=\"$L_TRY_AGAIN\"></form>"
		fi
		echo "</td></tr>
		</table>
		</div>
		<div id=\"scritta\">$L_REC_PASSWORD</div>
		</body></html>"
		exit
	fi
	$C_ZT_BIN_DIR/zt "Cancella" "/tmp/${USER}passasterisk"
	echo "<div id=\"paginaprivacy\">
	<table class=\"tabella\" align=\"center\">
	<tr><td align=\"center\">
	<font color=\"blue\" size=\"4\">$L_ASTERISK_NUMBER $C_PHONE_ASTERISK_FORGOT</font>
	<p><form action=\"forgotasterisk.sh\" method=\"post\">
	<input type=\"hidden\" name=\"CONTROL\" value=\"ASTERISK\">
	<input type=\"hidden\" name=\"USER\" value=\"$USER\">
	<input type=\"hidden\" name=\"PHONE\" value=\"$PHONE\">
	<input type=\"submit\" name=\"CONTINUE\" class=\"bottone\" value=\"$L_CONTINUE\"></form>
	</td></tr>
	</table>
	</div>
	<div id=\"scritta\">$L_REC_PASSWORD</div>
	</body></html>"
	exit
fi
MAC=$(arp -an | grep $REMOTE_ADDR | awk '{split ($0, a, " ");print a['4']}')
MAC=$(echo "$MAC" | tr '[:lower:]' '[:upper:]')
if [ -n "$(cat $C_ZT_CONF_DIR/macblocked | grep $MAC)" ];then
		echo "<div id=\"paginaprivacy\">
		<table class=\"tabella\" align=\"center\">
		<tr><td align=\"center\">
		<p><font color=\"red\">$L_BLOCK_MAC<p>$BLOCK_MAC<p>$MAC</font>
		<form action=\"register.sh\" method=\"post\">
		<input type=\"submit\" name=\"CLOSE\" class=\"bottone\" value=\"$L_CLOSE\"></form>
		</td></tr></table>
		</div>
		</body></html>"
		exit
fi
echo "<div id=\"paginareg\">
<table class=\"tabellareg\" align=\"center\">
<tr><td align=\"center\">
<form name=\"REGISTER\" method=\"POST\" action=\"forgotasterisk.sh\">
<table>
<tr><td>$L_USER</td>
<td><input type=\"text\" name=\"USER\" value=\"\"></td></tr>
<tr><td>$L_PHONE*</td>
<td><input type=\"tel\" name=\"PHONE\" value=\"$C_PREFIX\"></td></tr>
</table>
<br>$L_COPY_CATPCHA<br>
<input type=\"text\" id=\"txtCaptcha\" style=\"background-image:url(../images/imgcaptcha); text-align:center; border:none;
font-weight:bold; font-size: 16px;\"><br>
<input type=\"tel\" id=\"txtInput\">
<p><input type=\"submit\" name=\"salva\" class=\"bottone\" value=\"$L_SAVE\" onclick=\"ValidCaptcha();\"></form>
</td></tr></table>
</td></tr></table>
</div>
<div id=\"prefisso\">* $L_WITH_PREFIX (es. <font color=\"red\">39</font>3393467765)</div>
<div id=\"scritta\">$L_REC_PASSWORD</div>
</body>
</html>"
