#!/bin/bash
#***********************************************************************
# Zerotruth - interface for Zeroshell Captive Portal
# Version: 4.0
# Copyright (C) 2012-2017 Nello Dalla Costa. All rights reserved.
# License:	GNU/GPL, see COPYING
# This file is part of Zerotruth
# Zerotruth is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Zerotruth is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#***********************************************************************
echo "Content-type: text/html"
echo ""

source /DB/apache2/cgi-bin/zerotruth/conf/zt.config
if [ -n "$QUERY_STRING" ];then
	declare -a QUERYSTRING=( $( env | grep 'QUERY_STRING' | sed 's/QUERY_STRING=//g' | sed 's/&/ /g' ) )
	for element in ${QUERYSTRING[@]}; do
		name=$( echo $element|cut -d= -f1 )
		value=$( echo $element|cut -d= -f2 )
		eval $name=\'$value\'
	done
fi
if [ "$(echo "$HTTP_COOKIE" | cut -d'=' -f1)" == "ZtLang" ];then
	LANGUAGE="$(echo "$HTTP_COOKIE" | cut -d'=' -f2)"
else
	LANGUAGE="$C_LANGUAGE"
fi
source /DB/apache2/cgi-bin/zerotruth/functions.sh
source /DB/apache2/cgi-bin/zerotruth/language/$LANGUAGE/$LANGUAGE.sh

CR=$(/usr/local/bin/ldapsearch -xLLL -b "ou=People,$C_LDAPBASE" uid=$USERNAME loginRemote | grep '^loginRemote' | awk '{print $2}')
if [ -z $(cat $C_SYSTEM/cp/Connected/$IPCON/User | grep $USERNAME) ] && [ "$CR" == "?" ];then
	echo "<script language=\"javascript\">
	location.replace(\"http://www.zerotruth.net\");
	</script>"
fi

echo "<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>$C_HOTSPOT_NAME</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">"

cat <<EOF
<script src="/js/zt.js" type="text/javascript"></script>
<style type="text/css">
body {
	font: 10px "Trebuchet MS",Arial,sans-serif;
	text-align: center;
}
input {
	color: #201561;
	background: #feffc5;
	border: 1px solid #c15959;
}
input.bottoneconf {
	display: block;width: 138px;height: 20px;
	border: 0px;
	display: inline-block;
	text-decoration: none;
	text-align: center;
	font: bold 14px/18px "Trebuchet MS",Arial,sans-serif;
	background: url(/images/template/bottone.png);
	color: #286C98
}
input.bottone:hover {
	color: #0D4B72
}
#logouser{
	position:absolute;
	top: 15px;
	left:50%;
	margin-left: -229px;
	z-index:10;
}

.interna {
	width: 600px;
	border: 2px solid #cfcfcf;
	background-color: #f3f3f3;
	margin:0 auto;
	font: 12px "Trebuchet MS",Arial,sans-serif;
}

.esterna {
	table-layout: fixed;
	width: 659px;
	border: 2px solid #cfcfcf;
	background-color: #ffffff;
	margin:0 auto;
}

table {
	 border-collapse: collapse ;
	 border-color: #a0a0f0 ;
}

</style>

</script>
</head><body>
EOF


if [ "$C_FORM_DATE" == "ita" ];then
	TODAYN=$(date +%d/%m/%Y)
else
	TODAYN=$(date +%Y/%m/%d)
fi
ldap_search_people "uid=$USERNAME"
ldap_search_radius "$USERNAME"
[ -z "$EMAIL" ] && EMAIL="$L_NOT_ADDED"
[ -z "$PHONE" ] && PHONE="$L_NOT_ADDED"
CREATED_YEAR=$(echo "$CREATED" | cut -c 1-4 )
CREATED_MONTH=$(echo "$CREATED" | cut -c 5-6 )
CREATED_DAY=$(echo "$CREATED" | cut -c 7-8 )
if [ "$C_FORM_DATE" == "ita" ];then
	DATE_CREATED="$CREATED_DAY/$CREATED_MONTH/$CREATED_YEAR"
else
	DATE_CREATED="$CREATED_YEAR/$CREATED_MONTH/$CREATED_DAY"
fi
if [ "$VALIDITY" == "yes" ];then
	EXPIRED="$L_NO"
else
	EXPIRED="$L_YES"
fi
if [ "$EXPIRE" == "24836" ];then
	EXPIRE="$L_NO_LIMIT"
else
	if [ "$C_FORM_DATE" == "ita" ];then
		EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%d/%m/%Y)
	else
		EXPIRE=$(date -d "1970-01-01 $EXPIRE days" +%Y/%m/%d)
	fi
fi
if [ -n "$(echo $PASSWORD | cut -sd"-" -f2)" ];then
	BLOCKED="$L_YES"
else
	BLOCKED="$L_NO"
fi
PASSWORD=$( echo $PASSWORD | cut -d'-' -f1)
if [ -z $(cat $C_CLASSES_DIR/$CLASS/CostH) ];then
	COST_HOUR="$L_NOPAID"
else
	COST_HOUR=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/CostH)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	[ -z $(echo $COST_HOUR | cut -sd'.' -f1) ] && COST_HOUR="0$COST_HOUR"
	COST_HOUR="$COST_HOUR $C_CURRENCY"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/CostM) ];then
	COST_MB="$L_NOPAID"
else
	COST_MB=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/CostM)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	[ -z $(echo $COST_MB | cut -sd'.' -f1) ] && COST_MB="0$COST_MB"
	COST_MB="$COST_MB $C_CURRENCY"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/MB) ];then
	LIMIT_MB="$L_NO_LIMIT"
else
	LIMIT_MB=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/MB)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	LIMIT_MB="$LIMIT_MB MB"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/Hours) ];then
	LIMIT_HOUR="$L_NO_LIMIT"
else
	LIMIT_HOUR="$(cat $C_CLASSES_DIR/$CLASS/Hours) $L_HOURS"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/HoursDay) ];then
	HOURSDAY="$L_NO_LIMIT"
else
	HOURSDAY=$(cat $C_CLASSES_DIR/$CLASS/HoursDay)
	[ "$HOURSDAY" -lt 10 ] && HOURSDAY="0$HOURSDAY"
	HOURSDAY="$HOURSDAY:00"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/HoursMonth) ];then
	HOURSMONTH="$L_NO_LIMIT"
else
	HOURSMONTH=$(cat $C_CLASSES_DIR/$CLASS/HoursMonth)
	[ "$HOURSMONTH" -lt 10 ] && HOURSMONTH="0$HOURSMONTH"
	HOURSMONTH="$HOURSMONTH:00"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/MBDay) ];then
	MBDAY="$L_NO_LIMIT"
else
	MBDAY=$(cat $C_CLASSES_DIR/$CLASS/MBDay)
	MBDAY="$MBDAY.00"
fi
if [ -z $(cat $C_CLASSES_DIR/$CLASS/MBMonth) ];then
	MBMONTH="$L_NO_LIMIT"
else
	MBMONTH=$(cat $C_CLASSES_DIR/$CLASS/MBMonth)
	MBMONTH="$MBMONTH.00"
fi
BW=$(cat $C_CLASSES_DIR/$CLASS/Mbits)
if [[ -z $BW || -z "$C_SHAPER" ]];then
	BW="$L_NO_LIMIT"
else
	BW=$(echo "scale=$C_DECIMAL;$(cat $C_CLASSES_DIR/$CLASS/Mbits)/1" | $C_ZT_BIN_DIR/bc -l | sed 's/^\./0./' )
	BW="$BW Mbit"
fi
TYPE=$(cat $C_CLASSES_DIR/$CLASS/ChargeType)
[ "$TYPE" == "pre" ] &&	PAYMENT="$L_PREPAID"
[ "$TYPE" == "post" ] && PAYMENT="$L_POSTPAID"
[ -z "$TYPE" ] && PAYMENT="$L_NOPAID"
CREDIT=$(cat $C_ACCT_DIR/credits/$USERNAME/Credit | awk '{printf("%.2f\n", $0)}')
if [ -z "$CREDIT" ];then
	CREDIT="$L_NOPAID"
else
	CREDIT="$CREDIT $C_CURRENCY"
fi

CONNECTED=$(cat $C_CP_DIR/Connected/*/User | cut -sd'@' -f1)
CONTROL_CON=$(echo "$CONNECTED" | grep "$USERNAME")
if [ -n "$CONTROL_CON" ];then
	CONTROL_CON="$L_YES"
else
	CONTROL_CON="$L_NO"
fi
YEAR=$(date +%Y)
MONTH=$(echo $(date +%m) | sed 's/^0//g')
TODAY=$(echo $(date +%d) | sed 's/^0//g')
if [ -f  $C_ACCT_DIR/entries/$USERNAME/TimeD$TODAY ];then
	TIME_TODAY=$(oraconv $(cat $C_ACCT_DIR/entries/$USERNAME/TimeD$TODAY))
else
	TIME_TODAY="00:00:00"
fi
if [ -f  $C_ACCT_DIR/entries/$USERNAME/MBD$TODAY ];then
	TRAFFIC_TODAY=$(cat $C_ACCT_DIR/entries/$USERNAME/MBD$TODAY)
	TRAFFIC_TODAY=$( echo "$TRAFFIC_TODAY/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
else
	TRAFFIC_TODAY="0.00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/TimeM$MONTH ];then
	TIME_MONTH=$(oraconv $(cat $C_ACCT_DIR/entries/$USERNAME/TimeM$MONTH))
else
	TIME_MONTH="00:00:00"
fi
if [ -f  $C_ACCT_DIR/entries/$USERNAME/MBM$MONTH ];then
	TRAFFIC_MONTH=$(cat $C_ACCT_DIR/entries/$USERNAME/MBM$MONTH)
	TRAFFIC_MONTH=$( echo "$TRAFFIC_MONTH/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
else
	TRAFFIC_MONTH="0.00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/Time ];then
	TIME_YEAR=$(oraconv $(cat $C_ACCT_DIR/entries/$USERNAME/TimeY$YEAR))
else
	TIME_YEAR="00:00:00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/MB ];then
	TRAFFIC_YEAR=$(cat $C_ACCT_DIR/entries/$USERNAME/MBY$YEAR)
	TRAFFIC_YEAR=$( echo "$TRAFFIC_YEAR/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
else
	TRAFFIC_YEAR="0.00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/Time ];then
	TIME_TOT=$(oraconv $(cat $C_ACCT_DIR/entries/$USERNAME/Time))
else
	TIME_TOT="00:00:00"
fi

if [ -f  $C_ACCT_DIR/entries/$USERNAME/MB ];then
	TRAFFIC_TOT=$(cat $C_ACCT_DIR/entries/$USERNAME/MB)
	TRAFFIC_TOT=$(echo "$TRAFFIC_TOT/1048576" | $C_ZT_BIN_DIR/bc -l | awk '{printf("%.2f\n", $0)}')
else
	TRAFFIC_TOT="0.00"
fi

echo "<table class=\"esterna\"></tr><td align=\"center\">
<img src=\"/images/template/imguser.png\" WIDTH=\"650\"  border=\"0\">
<br><font color=\"#0000FF\" size=\"4\"><center>$L_USER_DETAILS1: $USERNAME</font><br>
<font color=\"#0000FF\" size=\"2\">$TODAYN $(date +%H:%M:%S)</font>
<br><img src=\"/images/template/barra.png\">
<p>
<form action=\"detailsolcon.sh\" method=\"GET\">
	<input type=\"hidden\" name=\"USERNAME\" value=\"$USERNAME\">
	<input type=\"hidden\" name=\"IPCON\" value=\"$IPCON\">
	<input type=\"submit\" name=\"CON\" class=\"bottoneconf\" value=\"$L_SESSIONS\">
</form>
<p>
<table class=\"interna\" BGCOLOR=\"#f3f3f3\" border=\"1\" align=\"center\">
	<tr>
		<td class=\"intesta\" background=\"/images/template/imgtable.png\" colspan=\"2\" align=\"center\">User</td>
		<td class=\"intesta\" background=\"/images/template/imgtable.png\" colspan=\"2\" align=\"center\">$L_CLASS: $CLASS</td>
	</tr>
	<tr>
		<td width=\"200px\">&nbsp;Username:</td>
		<td width=\"100px\">&nbsp;$USERNAME</td>
		<td width=\"200px\">&nbsp;$L_PAYMENT:</td>
		<td width=\"100px\">&nbsp;$PAYMENT</td>
	</tr>
	<tr>
		<td>&nbsp;$L_NAME:</td>
		<td>&nbsp;$NAME</td>
		<td>&nbsp;$L_CREDIT:</td>
		<td>&nbsp;$CREDIT</td>
	</tr>
	<tr>
		<td>&nbsp;$L_LAST_NAME:</td>
		<td>&nbsp;$LAST_NAME</td>
		<td>&nbsp;$L_COSTMB:</td>
		<td>&nbsp;$COST_MB</td>
	</tr>
	<tr>
		<td>&nbsp;$L_EMAIL:</td>
		<td>&nbsp;$EMAIL</td>
		<td>&nbsp;$L_COSTH:</td>
		<td>&nbsp;$COST_HOUR</td>
	</tr>
	<tr>
		<td>&nbsp;$L_PHONE:</td>
		<td>&nbsp;$PHONE</td>
		<td>&nbsp;$L_TRAFFIC:</td>
		<td>&nbsp;$LIMIT_MB</td>
	</tr>
	<tr>
		<td>&nbsp;$L_CREATED:</td>
		<td>&nbsp;$DATE_CREATED</td>
		<td>&nbsp;$L_TIME:</td>
		<td>&nbsp;$LIMIT_HOUR</td>
	</tr>
	<tr>
		<td>&nbsp;$L_EXPIRY:</td>
		<td>&nbsp;$EXPIRE</td>
		<td>&nbsp;$L_BANDWIDTH (Mbit/s):</td>
		<td>&nbsp;$BW</td>
	</tr>
</table>
<br>

<table class=\"interna\" BGCOLOR=\"#f3f3f3\" border=\"1\" align=\"center\">

	<tr>
		<td width=\"200px\">&nbsp;$L_LIMIT_HOURS $L_FOR_DAY: </td>
		<td width=\"100px\">&nbsp;$HOURSDAY</td>
		<td width=\"200px\">&nbsp;$L_LIMIT_HOURS $L_FOR_MONTH:</td>
		<td width=\"100px\">&nbsp;$HOURSMONTH</td>
	</tr>
	<tr>
		<td>&nbsp;$L_HOURS ($L_TODAY):</td>
		<td>&nbsp;$TIME_TODAY</td>
		<td>&nbsp;$L_HOURS ($L_THIS_MONTH):</td>
		<td>&nbsp;$TIME_MONTH</td>
	</tr>
	<tr>
		<td>&nbsp;$L_HOURS ($L_THIS_YEAR):</td>
		<td>&nbsp;$TIME_YEAR</td>
		<td>&nbsp;$L_HOURS ($L_TOTAL):</td>
		<td>&nbsp;$TIME_TOT</td>
	</tr>
	<tr>
		<td>&nbsp;$L_LIMIT_MB $L_FOR_DAY: </td>
		<td>&nbsp;$MBDAY</td>
		<td>&nbsp;$L_LIMIT_MB $L_FOR_MONTH:</td>
		<td>&nbsp;$MBMONTH</td>
	</tr>
	<tr>
		<td>&nbsp;$L_TRAFFIC ($L_TODAY):</td>
		<td>&nbsp;$TRAFFIC_TODAY MB</td>
		<td>&nbsp;$L_TRAFFIC ($L_THIS_MONTH):</td>
		<td>&nbsp;$TRAFFIC_MONTH MB</td>
	</tr>
	<tr>
		<td>&nbsp;$L_TRAFFIC ($L_THIS_YEAR):</td>
		<td>&nbsp;$TRAFFIC_YEAR MB</td>
		<td>&nbsp;$L_TRAFFIC ($L_TOTAL):</td>
		<td>&nbsp;$TRAFFIC_TOT MB</td>
	</tr>
</table></table>
<p><p>
</body>
</html>"
